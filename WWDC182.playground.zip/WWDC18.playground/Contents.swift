
//WWDC18 Playground
//By: Mohamed Salah
//Hope you have fun expiriencing my playground 😇

//Start Date: 14/3/2018 12:02 PM

import UIKit
import AVFoundation
import PlaygroundSupport

let Cities = Constants.Cities
let Colors = Constants.Colors

public class scrollView: UIScrollView, UIScrollViewDelegate {
    var citiesImg = [UIImageView]()
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.delegate = self
        self.contentSize = CGSize(width: frame.width*4, height: 350)
        self.isPagingEnabled = true
        self.showsHorizontalScrollIndicator = false
        self.bounces = false
        self.frame.origin.y += 100
        self.alpha = 0
        
        for i in Cities.count {
            let cityView = UIView(frame: self.bounds)
            let cityImg = UIImageView(frame: CGRect(x: -(frame.width/2), y: 0, width: frame.width*2, height: frame.height))
            
            cityView.clipsToBounds = true
            cityView.frame.origin.x = self.frame.width*CGFloat(i)
            
            cityImg.image = UIImage(named: Cities[i].name.lowercased().replacingOccurrences(of: " ", with: ""))
            cityImg.contentMode = .scaleAspectFit
            cityImg.alpha = 0.97
            
            citiesImg.append(cityImg)
            
            cityView.addSubview(cityImg)
            self.addSubview(cityView)
        }
        
        startAnimating(lastIndex: 1, currentIndex: 0)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var delete = false
    public func startAnimating(lastIndex: Int, currentIndex: Int) {
        
        UIView.animate(withDuration: 20, delay: 0, options: [.curveEaseInOut], animations: {
            self.citiesImg[currentIndex].frame.origin.x = 0
        }, completion: {finished in
            if !self.delete {
                UIView.animate(withDuration: 40, delay: 1, options: [.curveEaseInOut, .repeat, .autoreverse], animations: {
                    self.citiesImg[currentIndex].frame.origin.x = -self.frame.width
                }, completion: nil)
            }
        })
        
        delete = true
        citiesImg[lastIndex].layer.removeAllAnimations()
        delete = false
        citiesImg[lastIndex].frame.origin.x = -(frame.width/2)
    }
}

//minimum height for the best experience = 450

let viewHeight: CGFloat = 630
let viewWidth = viewHeight/1.75

let viewWidthHalf = viewWidth/2
let viewHeightHalf = viewHeight/2
let viewHeight35th = viewHeight/35

let cloudHeight = viewHeight/3.5

let view = mainView(frame: CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight))
let extraView = UIView(frame: view.bounds)

let start = startBtn(frame: CGRect(x: (view.frame.width/2)-((view.frame.width/1.4)/2), y: (view.frame.height/2)-((view.frame.width/1.4)/2), width: view.frame.width/1.4, height: view.frame.width/1.4))

let maskPath = UIBezierPath(rect: view.frame)
let btnOval = UIBezierPath(ovalIn: start.frame)
maskPath.append(btnOval.reversing())

let maskLayer = CAShapeLayer()
maskLayer.path = maskPath.cgPath

let blurEffectView: UIVisualEffectView = {
    let blur = UIVisualEffectView(effect: UIBlurEffect(style: UIBlurEffectStyle.dark))
    
    blur.layer.mask = maskLayer
    blur.frame = view.bounds
    blur.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    
    return blur
}()

let playgroundTitle: UILabel = {
    let label = UILabel(frame: CGRect(x: viewHeight35th, y: start.frame.maxY+(viewHeight35th), width: viewWidth-((viewHeight35th)*2), height: viewHeight/14))
    label.text = "Great Cities"
    label.textColor = Colors[2]
    
    label.setupLabel(bold: true, fontSize: viewHeight/15.55)
    return label
}()

let aboutBtn: UIButton = {
    let btn = UIButton(frame: CGRect(x: viewWidth-(viewHeight/23)-(viewHeight35th), y: viewHeight35th, width: viewHeight/23, height: viewHeight/23))
    
    btn.setImage(UIImage(named: "about")?.withRenderingMode(.alwaysTemplate), for: .normal)
    btn.imageView?.contentMode = .scaleAspectFit
    btn.tintColor = Colors[2]
    
    return btn
}()

let logo: UIImageView = {
    let img = UIImageView(frame: CGRect(x: viewHeight/37, y: viewHeight-(viewHeight/17)-(viewHeight/37), width: viewHeight/17, height: viewHeight/17))
    
    img.image = UIImage(named: "logo")
    img.contentMode = .scaleAspectFit
    img.alpha = 0.7
    return img
}()

let aboutBody: UILabel = {
    let label = UILabel(frame: CGRect(x: viewHeight35th, y: start.frame.minY, width: viewWidth-((viewHeight35th)*2), height: start.frame.height))
    
    label.text = "This playground shows you some information about 4 of the most famous beautiful cities in the world."
    label.textColor = Colors[2]
    label.numberOfLines = 4
    label.alpha = 0
    label.setupLabel(bold: false, fontSize: viewHeight/16)
    
    return label
}()

let aboutDes: UILabel = {
    let label = UILabel(frame: CGRect(x: (viewHeight35th), y: viewHeight-((viewHeight/25)+logo.frame.height), width: viewWidth-(((viewHeight35th)*2)), height: logo.frame.height))
    
    label.text = "Designed and developed by: Mohamed Salah"
    label.textColor = Colors[2]
    label.alpha = 0
    label.baselineAdjustment = .alignCenters
    label.setupLabel(bold: false, fontSize: viewHeight/17)
    
    return label
}()

let backBtn: UIButton = {
    let btn = UIButton(frame: CGRect(x: aboutBtn.frame.minY, y: -aboutBtn.frame.width, width: aboutBtn.frame.width, height: aboutBtn.frame.width))
    
    btn.setImage(UIImage(named: "back"), for: .normal)
    btn.imageView?.contentMode = .scaleAspectFit
    return btn
}()

let moon: UIImageView = {
    let img = UIImageView(frame: CGRect(x: viewWidthHalf-((viewWidth/1.5)/2), y: viewHeight/9, width: viewWidth/1.5, height: viewWidth/1.5))
    
    img.image = UIImage(named: "moon")
    img.alpha = 0
    return img
}()

let scrollViewCity = scrollView(frame: CGRect(x: 0, y: moon.frame.minY, width: viewWidth, height: viewHeightHalf))

let cloud1: UIImageView = {
    let img = UIImageView(frame: CGRect(x: -viewWidth/1.8, y: moon.frame.minY-(viewHeight/14), width: viewWidth, height: cloudHeight))
    
    img.image = UIImage(named: "cloud3")
    img.contentMode = .scaleAspectFit
    img.frame.origin.x -= img.frame.width
    img.alpha = 0
    return img
}()
let cloud2: UIImageView = {
    let img = UIImageView(frame: CGRect(x: viewWidth-(viewWidth/1.4), y: moon.frame.maxY-(viewHeight/3.18), width: viewWidth, height: cloudHeight))
    
    img.image = UIImage(named: "cloud2")
    img.contentMode = .scaleAspectFit
    img.frame.origin.x += img.frame.width
    img.alpha = 0
    return img
}()
let cloud3: UIImageView = {
    let img = UIImageView(frame: CGRect(x: -viewWidthHalf, y: moon.frame.maxY-(viewHeight/4.6), width: viewWidth, height: cloudHeight))
    
    img.image = UIImage(named: "cloud1")
    img.contentMode = .scaleAspectFit
    img.frame.origin.x -= img.frame.width
    img.alpha = 0
    return img
}()

let cloud1ex: UIImageView = {
    let img = UIImageView(frame: CGRect(x: -viewWidth/1.8, y: moon.frame.minY-(viewHeight/14), width: viewWidth, height: cloudHeight))
    
    img.image = UIImage(named: "cloud3")
    img.contentMode = .scaleAspectFit
    img.alpha = 0
    return img
}()
let cloud2ex: UIImageView = {
    let img = UIImageView(frame: CGRect(x: viewWidth-(viewWidth/1.4), y: moon.frame.maxY-(viewHeight/3.18), width: viewWidth, height: cloudHeight))
    
    img.image = UIImage(named: "cloud2")
    img.contentMode = .scaleAspectFit
    img.alpha = 0
    return img
}()
let cloud3ex: UIImageView = {
    let img = UIImageView(frame: CGRect(x: -viewWidthHalf, y: moon.frame.maxY-(viewHeight/4.6), width: viewWidth, height: cloudHeight))
    
    img.image = UIImage(named: "cloud1")
    img.contentMode = .scaleAspectFit
    img.alpha = 0
    return img
}()

let pagecontrol: UIPageControl = {
    let pcontrol = UIPageControl(frame: CGRect(x: 0, y: viewHeight-(viewHeight/14), width: viewWidth, height: viewHeight/17.5))
    
    pcontrol.numberOfPages = 4
    pcontrol.currentPageIndicatorTintColor = Colors[2]
    pcontrol.pageIndicatorTintColor = Colors[3]
    pcontrol.isUserInteractionEnabled = false
    return pcontrol
}()

let exploreBtn: UIButton = {
    let btn = UIButton(frame: CGRect(x: 0, y: pagecontrol.frame.minY-(viewHeight/11.66), width: viewWidth, height: playgroundTitle.frame.height))
    
    let titleSpaced = NSMutableAttributedString(string: "Explore")
    titleSpaced.addAttribute(NSAttributedStringKey.kern, value: CGFloat(1.5), range: NSRange(location: 0, length: titleSpaced.length))
    
    btn.backgroundColor = Colors[4]
    btn.layer.cornerRadius = btn.frame.height/2
    btn.setAttributedTitle(titleSpaced, for: .normal)
    btn.titleLabel?.textColor = Colors[2]
    btn.titleLabel?.setupLabel(bold: true, fontSize: viewHeight/31)
    btn.alpha = 0
    return btn
}()

let subLabel: UILabel = {
    let label = UILabel(frame: CGRect(x: 0, y: exploreBtn.frame.minY-(viewHeight/7.77), width: viewWidth, height: exploreBtn.frame.height))
    
    label.text = Cities[0].des
    label.textColor = Colors[5]
    
    label.setupLabel(bold: false, fontSize: viewHeight/20)
    label.frame.size.width = (label.text?.width(height: label.frame.height, font: label.font))!
    label.frame.origin.x = (viewWidthHalf)-(label.frame.width/2)
    label.alpha = 0
    return label
}()
let titleLabel: UILabel = {
    let label = UILabel(frame: CGRect(x: 0, y: subLabel.frame.minY-(viewHeight/14.89), width: viewWidth, height: exploreBtn.frame.height))
    
    label.text = Cities[0].name
    label.textColor = Colors[2]
    
    label.setupLabel(bold: true, fontSize: viewHeight/15.55)
    label.frame.size.width = (label.text?.width(height: label.frame.height, font: label.font))!
    label.frame.origin.x = (viewWidthHalf)-(label.frame.width/2)
    label.alpha = 0
    return label
}()

let scrollViewDetails = detailsScrollView(frame: CGRect(x: viewWidth, y: viewHeight-(viewHeight/4.375)-(viewHeight/46.6), width: viewWidth, height: viewHeight/4.375))

moon.frame.origin.y -= viewHeight/4

titleLabel.frame.origin.y += 50
subLabel.frame.origin.y += 50

pagecontrol.frame.origin.y += viewHeight/10

public class Responder {
    var firstTime = true
    @objc func handleStartBtn() {
        firstTime = false
        view.addStars()
        receiver.playCitySound(cityIndex: 0)
        
        UIView.animate(withDuration: 1.2, delay: 0, options: [.curveEaseInOut], animations: {
            
            aboutBtn.tintColor = Colors[5]
            aboutBtn.alpha = 0.7
            
            blurEffectView.transform = CGAffineTransform(scaleX: 5, y: 5)
            start.transform = CGAffineTransform(scaleX: 5, y: 5)
            extraView.alpha = 0
            
            moon.frame.origin.y += viewHeight/4
            moon.alpha = 1
            
            scrollViewCity.frame.origin.y -= 100
            scrollViewCity.alpha = 1
            
            cloud1.frame.origin.x += cloud1.frame.width
            cloud2.frame.origin.x -= cloud2.frame.width
            cloud3.frame.origin.x += cloud3.frame.width
            
            cloud1.alpha = 1
            cloud2.alpha = 1
            cloud3.alpha = 1
            
            titleLabel.frame.origin.y -= 50
            subLabel.frame.origin.y -= 50
            
            titleLabel.alpha = 1
            subLabel.alpha = 1
            
            exploreBtn.frame.origin.x = viewWidthHalf-((viewWidth/2.2)/2)
            exploreBtn.frame.size.width = viewWidth/2.2
            exploreBtn.alpha = 1
            
            pagecontrol.frame.origin.y -= viewHeight/10
            
        }, completion: {finished in
            blurEffectView.layer.mask = nil
            blurEffectView.transform = CGAffineTransform(scaleX: 1, y: 1)
            
            playgroundTitle.text = "WWDC18 Great Cities"
            playgroundTitle.frame.origin.y = aboutBtn.frame.maxY+(viewHeight/25)
            playgroundTitle.textColor = Colors[5]
            
            aboutBody.alpha = 1
            aboutDes.alpha = 1
            
            logo.frame.origin = CGPoint(x: viewWidthHalf-(logo.frame.width/2), y: viewHeight-((viewHeight/17)*2)-((viewHeight/37)*2))
            
            start.removeFromSuperview()
        })
    }
    
    var about = false
    @objc func handleAboutBtn() {
        about = true
        UIView.animate(withDuration: 1, delay: 0, options: [.curveEaseInOut], animations: {
            
            backBtn.frame.origin.y = viewHeight35th
            aboutBtn.frame.origin.y = -aboutBtn.frame.height
            
            if !self.firstTime {
                extraView.alpha = 1
            }else {
                blurEffectView.layer.mask = nil
                start.alpha = 0
                
                playgroundTitle.changeTextAnimated(str: "WWDC18 Great Cities", title: false)
                playgroundTitle.frame.origin.y = backBtn.frame.maxY+(viewHeight/25)
                playgroundTitle.textColor = Colors[5]
                
                logo.frame.origin = CGPoint(x: viewWidthHalf-(logo.frame.width/2), y: viewHeight-((viewHeight/17)*2)-((viewHeight/37)*2))
                
                aboutDes.alpha = 1
            }
            
        }, completion: {finished in
            if self.firstTime {
                UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseInOut], animations: {
                    aboutBody.alpha = 1
                }, completion: nil)
            }
        })
    }
    
    var lastIndex = 0
    @objc func handleExploreBtn() {
        UIView.animate(withDuration: 1, delay: 0, options: [.curveEaseInOut], animations: {
            
            if self.lastIndex != pagecontrol.currentPage {
                scrollViewDetails.update(city: Cities[pagecontrol.currentPage])
                self.lastIndex = pagecontrol.currentPage
            }
            scrollViewCity.isUserInteractionEnabled = false
            
            titleLabel.frame = CGRect(x: viewHeight35th, y: scrollViewCity.frame.maxY-10, width: (titleLabel.text?.width(height: titleLabel.frame.height, font: titleLabel.font))!, height: titleLabel.frame.height)
            subLabel.frame = CGRect(x: viewHeight35th, y: titleLabel.frame.maxY-5, width: (subLabel.text?.width(height: titleLabel.frame.height, font: subLabel.font))!, height: titleLabel.frame.height)
            
            exploreBtn.frame.origin.x -= viewWidth
            pagecontrol.frame.origin.x -= viewWidth
            
            scrollViewDetails.frame.origin.x = 0
            
            backBtn.frame.origin.y = viewHeight35th
            aboutBtn.frame.origin.y = -aboutBtn.frame.height
            
        }, completion: nil)
    }
    
    @objc func handleBackBtn() {
        if about {
            about = false
            UIView.animate(withDuration: 1, delay: 0, options: [.curveEaseInOut], animations: {
                
                backBtn.frame.origin.y = -backBtn.frame.height
                aboutBtn.frame.origin.y = viewHeight35th
                
                if !self.firstTime {
                    extraView.alpha = 0
                } else {
                    start.alpha = 1
                    blurEffectView.layer.mask = maskLayer
                    
                    playgroundTitle.text = "Great Cities"
                    playgroundTitle.frame.origin.y = start.frame.maxY+(viewHeight35th)
                    playgroundTitle.textColor = Colors[2]
                    
                    logo.frame.origin = CGPoint(x: viewHeight/37, y: viewHeight-(viewHeight/17)-(viewHeight/37))
                    
                    aboutBody.alpha = 0
                    aboutDes.alpha = 0
                }
                
            }, completion: nil)
            
        }else {
            if scrollViewDetails.viewd {
                scrollViewDetails.update3d()
            }else {
                UIView.animate(withDuration: 1, delay: 0, options: [.curveEaseInOut], animations: {
                    
                    scrollViewDetails.contentOffset.x = 0
                    
                    scrollViewCity.isUserInteractionEnabled = true
                    
                    subLabel.frame.size.width = (subLabel.text?.width(height: subLabel.frame.height, font: subLabel.font))!
                    subLabel.frame.origin = CGPoint(x: (viewWidthHalf)-(subLabel.frame.width/2), y: exploreBtn.frame.minY-(viewHeight/7.77))
                    
                    titleLabel.frame.size.width = (titleLabel.text?.width(height: titleLabel.frame.height, font: titleLabel.font))!
                    titleLabel.frame.origin = CGPoint(x: (viewWidthHalf)-(titleLabel.frame.width/2), y: subLabel.frame.minY-(viewHeight/14.89))
                    
                    exploreBtn.frame.origin.x += viewWidth
                    pagecontrol.frame.origin.x += viewWidth
                    
                    scrollViewDetails.frame.origin.x = viewWidth
                    
                    backBtn.frame.origin.y = -backBtn.frame.height
                    aboutBtn.frame.origin.y = viewHeight35th
                    
                }, completion: nil)
            }
        }
    }
    
    var first = true
    var cityPlayer = AVAudioPlayer()
    let musicCity = ["loneliness", "september", "makemebelieve", "glazeduniverse"]
    
    func playCitySound(cityIndex: Int) {
        let url = Bundle.main.url(forResource: musicCity[cityIndex], withExtension: "mp3")!
        var delay = 0.0
        if first {
            first = false
        }else {
            cityPlayer.setVolume(0, fadeDuration: 0.8)
            delay = 0.85
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: {
            do {
                self.cityPlayer = try AVAudioPlayer(contentsOf: url)
                
                self.cityPlayer.numberOfLoops = -1
                self.cityPlayer.volume = 0.35
                self.cityPlayer.prepareToPlay()
                self.cityPlayer.play()
            } catch let error {
                print(error.localizedDescription)
            }
        })
    }
}

let receiver = Responder()

var lastScrollOffset: CGFloat = 0
var lastDir: scrollDirection = .undefined
var currentIndex = 0
var ex = false
var first = true

extension scrollView {
    public func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNumber = Int(round(self.contentOffset.x / self.frame.size.width))
        if currentIndex != pageNumber {
            if ex {
                ex = false
            }else {
                ex = true
            }
            
            subLabel.frame.origin.x = (viewWidthHalf)-(subLabel.frame.width/2)
            
            titleLabel.changeTextAnimated(str: Cities[pageNumber].name, title: true)
            subLabel.changeTextAnimated(str: Cities[pageNumber].des, title: true)
            
            scrollViewCity.startAnimating(lastIndex: currentIndex, currentIndex: pageNumber)
            
            currentIndex = pageNumber
            pagecontrol.currentPage = pageNumber
            
            receiver.playCitySound(cityIndex: pageNumber)
        }
        
        first = true
    }
    
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if lastScrollOffset > scrollView.contentOffset.x {
            lastDir = .right
            if first && (scrollView.contentOffset.x <= (CGFloat(currentIndex)*viewWidth)) {
                
                first = false
                
                if ex {
                    
                    cloud1.frame.origin.x = (-viewWidth/1.8)-viewWidth
                    cloud2.frame.origin.x = (viewWidth-(viewWidth/1.4))-viewWidth
                    cloud3.frame.origin.x = (-viewWidthHalf)-viewWidth
                }else {
                    cloud1ex.frame.origin.x = (-viewWidth/1.8)-viewWidth
                    cloud2ex.frame.origin.x = (viewWidth-(viewWidth/1.4))-viewWidth
                    cloud3ex.frame.origin.x = (-viewWidthHalf)-viewWidth
                }
            }
        } else if lastScrollOffset < scrollView.contentOffset.x {
            lastDir = .left
            if first && (scrollView.contentOffset.x > (CGFloat(currentIndex)*viewWidth)) {
                first = false
                
                if ex {
                    cloud1.frame.origin.x = (-viewWidth/1.8)+viewWidth
                    cloud2.frame.origin.x = (viewWidth-(viewWidth/1.4))+viewWidth
                    cloud3.frame.origin.x = (-viewWidthHalf)+viewWidth
                }else {
                    cloud1ex.frame.origin.x = (-viewWidth/1.8)+viewWidth
                    cloud2ex.frame.origin.x = (viewWidth-(viewWidth/1.4))+viewWidth
                    cloud3ex.frame.origin.x = (-viewWidthHalf)+viewWidth
                }
            }
        }
        
        UIView.animate(withDuration: 0.2, delay: 0, options: [.curveEaseInOut], animations: {
            cloud1.frame.origin.x += lastScrollOffset-scrollView.contentOffset.x
            cloud2.frame.origin.x += lastScrollOffset-scrollView.contentOffset.x
            cloud3.frame.origin.x += lastScrollOffset-scrollView.contentOffset.x
            
            cloud1ex.frame.origin.x += lastScrollOffset-scrollView.contentOffset.x
            cloud2ex.frame.origin.x += lastScrollOffset-scrollView.contentOffset.x
            cloud3ex.frame.origin.x += lastScrollOffset-scrollView.contentOffset.x
            
            var index = currentIndex
            if lastDir == .right {
                index = currentIndex-1
            }
            
            let scrolloff = scrollView.contentOffset.x-(CGFloat(index)*viewWidth)
            let percent = (scrolloff/viewWidth)*100
            
            var percentCloud = 1-(percent/100)
            var percentCloudex = (percent/100)
            
            if (ex && lastDir == .left) || (!ex && lastDir == .right) {
                percentCloudex = 1-(percent/100)
                percentCloud = (percent/100)
            }
            
            cloud1.alpha = percentCloud
            cloud2.alpha = percentCloud
            cloud3.alpha = percentCloud
            
            cloud1ex.alpha = percentCloudex
            cloud2ex.alpha = percentCloudex
            cloud3ex.alpha = percentCloudex
            
        }, completion: nil)
        
        lastScrollOffset = scrollView.contentOffset.x
    }
}

start.addTarget(receiver, action: #selector(Responder.handleStartBtn), for: .touchUpInside)
exploreBtn.addTarget(receiver, action: #selector(Responder.handleExploreBtn), for: .touchUpInside)
backBtn.addTarget(receiver, action: #selector(Responder.handleBackBtn), for: .touchUpInside)
aboutBtn.addTarget(receiver, action: #selector(Responder.handleAboutBtn), for: .touchUpInside)

extraView.addSubview(blurEffectView)
extraView.addSubview(start)
extraView.addSubview(playgroundTitle)
extraView.addSubview(aboutBody)
extraView.addSubview(logo)
extraView.addSubview(aboutDes)

view.addSubview(moon)

view.addSubview(scrollViewCity)

view.addSubview(cloud1)
view.addSubview(cloud2)
view.addSubview(cloud3)
view.addSubview(cloud1ex)
view.addSubview(cloud2ex)
view.addSubview(cloud3ex)

view.addSubview(pagecontrol)
view.addSubview(exploreBtn)

view.addSubview(titleLabel)
view.addSubview(subLabel)

view.addSubview(scrollViewDetails)
view.addSubview(extraView)
view.addSubview(backBtn)
view.addSubview(aboutBtn)

PlaygroundPage.current.liveView = view

//Thats it, thanks for reaching the bottom 😘
//Finish Date: 29/3/2017 8:14 AM
