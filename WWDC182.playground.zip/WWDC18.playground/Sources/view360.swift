
//View for showing a 360 degrees view to the city

import UIKit
import SceneKit

public class view360: UIView, UIGestureRecognizerDelegate {
    
    public var panSpeed = CGPoint(x: 0.005, y: 0.005)
    
    public var image: UIImage? {
        didSet {
            createGeometryNode()
            resetCameraAngles()
        }
    }
    
    private let radius: CGFloat = 10
    public let sceneView = SCNView()
    public let scene = SCNScene()
    private var geometryNode: SCNNode?
    private var prevLocation = CGPoint.zero
    private var prevBounds = CGRect.zero
    
    private lazy var cameraNode: SCNNode = {
        let node = SCNNode()
        let camera = SCNCamera()
        node.camera = camera
        return node
    }()
    
    private lazy var fovHeight: CGFloat = {
        return tan(self.yFov/2 * .pi / 180.0) * 2 * self.radius
    }()
    
    private var xFov: CGFloat {
        return yFov * self.bounds.width / self.bounds.height
    }
    
    private var yFov : CGFloat {
        get {
            return cameraNode.camera!.fieldOfView
        }
        set {
            cameraNode.camera!.fieldOfView = newValue
        }
    }
    
    public init(frame: CGRect, image: UIImage) {
        super.init(frame: frame)
        ({self.image = image})()
        initView()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initView() {
        self.clipsToBounds = true
        
        scene.rootNode.addChildNode(cameraNode)
        yFov = 70
        
        sceneView.frame = self.bounds
        sceneView.scene = scene
        self.addSubview(sceneView)
    }
    
    private func createGeometryNode() {
        guard let image = image else {return}
        
        geometryNode?.removeFromParentNode()
        
        let material = SCNMaterial()
        material.diffuse.contents = image
        material.diffuse.mipFilter = .nearest
        material.diffuse.magnificationFilter = .nearest
        material.diffuse.contentsTransform = SCNMatrix4MakeScale(-1, 1, 1)
        material.diffuse.wrapS = .repeat
        material.cullMode = .front
        
        let sphere = SCNSphere(radius: radius)
        sphere.segmentCount = 300
        sphere.firstMaterial = material
        
        let sphereNode = SCNNode()
        sphereNode.geometry = sphere
        geometryNode = sphereNode
        scene.rootNode.addChildNode(geometryNode!)
    }
    
    private func resetCameraAngles() {
        cameraNode.eulerAngles = SCNVector3Make(0, 0, 0)
    }
    
    public func startAnimatingCam() {
        let spin = CABasicAnimation(keyPath: "rotation")
        spin.fromValue = NSValue(scnVector4: SCNVector4(x: 0, y: 1, z: 0, w: Float(2 * Float.pi)))
        spin.toValue = NSValue(scnVector4: SCNVector4(x: 0, y: 1, z: 0, w: 0))
        spin.duration = 50
        spin.repeatCount = .infinity
        cameraNode.addAnimation(spin, forKey: "showAll")
    }
    
    public func stopAnimatingCam() {
        cameraNode.removeAllAnimations()
    }
    
    @objc public func handlePan(panRec: UIPanGestureRecognizer) {
        if panRec.state == .began {
            prevLocation = CGPoint.zero
        } else if panRec.state == .changed {
            
            let location = panRec.translation(in: sceneView)
            let orientation = cameraNode.eulerAngles
            var newOrientation = SCNVector3Make(orientation.x + Float(location.y - prevLocation.y) * Float(panSpeed.y),
                                                orientation.y + Float(location.x - prevLocation.x) * Float(panSpeed.x),
                                                orientation.z)
            
            newOrientation.x = max(min(newOrientation.x, 1.1),-1.1)
            
            cameraNode.eulerAngles = newOrientation
            prevLocation = location
        }
    }
}
