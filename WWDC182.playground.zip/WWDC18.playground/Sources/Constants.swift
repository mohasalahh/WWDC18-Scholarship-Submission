
//Just Constants 😅

import Foundation

public struct Constants {
    public static let Cities = [
        City(name: "Paris", des: "The City of Light", population: citiesPopulation[0], landArea: 87, waterArea: 18, elevation: 35),
        City(name: "New York", des: "The Big Apple", population: citiesPopulation[1], landArea: 783, waterArea: 429, elevation: 10),
        City(name: "London", des: "The Big Smoke", population: citiesPopulation[2], landArea: 1372, waterArea: 200, elevation: 35),
        City(name: "Rome", des: "The Eternal City", population: citiesPopulation[3], landArea: 1105, waterArea: 180, elevation: 21)]
    
    public static let citiesPopulation = [
        [2.8, 2.7, 2.8, 2.7, 2.5, 2.2, 2.1, 2.1, 2.1, 2.2],
        [12.5, 13.4, 14.8, 16.7, 18.2, 17.5, 17.9, 18.9, 19.3, 19.8],
        [8.1, 8.6, 8.2, 8.0, 7.5, 6.7, 6.4, 7.2, 8.2, 8.8],
        [0.9, 1.1, 1.6, 2.1, 2.7, 2.8, 2.7, 2.6, 2.6, 2.8]]
    
    public static let Colors = ["2d1e55".hexStringToUIColor(), "160633".hexStringToUIColor(), "f5edfe".hexStringToUIColor(), "3f3559".hexStringToUIColor(), "3d2175".hexStringToUIColor(), "a08dcd".hexStringToUIColor(), "7759ba".hexStringToUIColor(), "4010a0".hexStringToUIColor(), "180346".hexStringToUIColor(), "9e7ee7".hexStringToUIColor()]
}

public struct City {
    public let name: String
    public let des: String
    public let population: [Double]
    public let landArea: Int
    public let waterArea: Int
    public let elevation: Int
}
public struct Card {
    public let title: String
    public let value: String
    public let type: cardType
    public let data: Any
    
    public init(title: String, value: String, type: cardType, data: Any) {
        self.title = title
        self.value = value
        self.type = type
        self.data = data
    }
}

public enum scrollDirection {
    case right
    case left
    case undefined
}
public enum cardType {
    case graph
    case mountains
    case threesixty
    case circular
}
