
//The start button, drawn with CoreGraphics

import UIKit

public class startBtn: UIButton {
    let Colors = Constants.Colors
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func draw(_ rect: CGRect) {
        
        let bgCircle = UIBezierPath(ovalIn: rect)
        let triangle = UIBezierPath()
        
        let triangleLength = rect.height/2
        let startX = (rect.width/2) - (triangleLength / 2.45)
        let startY = (rect.width/2) - (triangleLength / 2)
        
        triangle.move(to: CGPoint(x: startX, y: startY))
        triangle.addLine(to: CGPoint(x: startX, y: startY + triangleLength))
        triangle.addLine(to: CGPoint(x: startX + triangleLength, y: startY + triangleLength/2))
        triangle.close()
        
        bgCircle.append(triangle)
        bgCircle.usesEvenOddFillRule = true
        
        let ly = CAShapeLayer()
        ly.path = bgCircle.cgPath
        ly.fillColor = Colors[2].cgColor
        
        self.layer.addSublayer(ly)
    }
}
