
//Extensions to shorten the process

import UIKit

public extension UIView {
    func addGradientWith(colors: [CGColor]) {
        let gradient: CAGradientLayer = CAGradientLayer()
        
        gradient.colors = colors
        gradient.locations = [0.0 , 1.0]
        gradient.startPoint = CGPoint(x: 1.0, y: 0.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        gradient.frame = CGRect(x: 0.0, y: 0.0, width: self.frame.size.width, height: self.frame.size.height)
        
        self.layer.insertSublayer(gradient, at: 0)
    }
}

public extension String {
    func hexStringToUIColor () -> UIColor {
       let uppercasedString: String = self.uppercased()
        
        var rgbValue: UInt32 = 0
        Scanner(string: uppercasedString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    func width(height: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedStringKey.font: font], context: nil)
        
        return ceil(boundingBox.width)
    }
}

public extension UILabel {
    func setupLabel(bold: Bool, fontSize: CGFloat) {
        var fontName = "fontreg"
        var fontNme = "HomizioNova-Light"
        if bold {
            fontName = "fontbold"
            fontNme = "HomizioNova"
        }
        let cfFontURL = Bundle.main.url(forResource: fontName, withExtension: "ttf")! as CFURL
        CTFontManagerRegisterFontsForURL(cfFontURL, CTFontManagerScope.process, nil)
        self.font = UIFont(name: fontNme, size: fontSize)
        
        self.adjustsFontSizeToFitWidth = true
        self.textAlignment = .center
    }
    
    func changeTextAnimated(str: String, title: Bool) {
        
        if title {
            self.frame.size.width = str.width(height: self.frame.height, font: self.font)
        }
        
        UIView.transition(with: self,
                          duration: 1,
                          options: .transitionCrossDissolve,
                          animations: {
                            self.text = str
                            
                            if title {
                                self.frame.origin.x = ((self.superview?.frame.width)!/2)-(self.frame.width/2)
                            }
            }, completion: nil)
    }
}

extension Int: Sequence {
    public func makeIterator() -> CountableRange<Int>.Iterator {
        return (0..<self).makeIterator()
    }
}

public extension City {
    func getTotalArea() -> Int {
        return self.waterArea+self.landArea
    }
}

public extension CGPoint {
    func midPointWithPoint(p2: CGPoint) -> CGPoint {
        return CGPoint(x: (self.x + p2.x) / 2, y: (self.y + p2.y) / 2)
    }
}

public extension Array where Element == CGPoint {
    
    func getCurvedFromStraight() -> UIBezierPath {
        let path = UIBezierPath()
        var p1: CGPoint = self[0]
        path.move(to: p1)
        
        for i in self.count {
            let p2: CGPoint = self[i]
            let midPoint: CGPoint = p1.midPointWithPoint(p2: p2)
            path.addQuadCurve(to: midPoint, controlPoint: controlPointForPoints(p1: midPoint, p2: p1))
            path.addQuadCurve(to: p2, controlPoint: controlPointForPoints(p1: midPoint, p2: p2))
            p1 = p2
        }
        
        return path
    }
    
    private func controlPointForPoints(p1: CGPoint, p2: CGPoint) -> CGPoint {
        var controlPoint: CGPoint = p1.midPointWithPoint(p2: p2)
        let diffY: CGFloat = abs(p2.y - controlPoint.y)
        
        if p1.y < p2.y {
            controlPoint.y += diffY
        } else if p1.y > p2.y {
            controlPoint.y -= diffY
        }
        
        return controlPoint
    }
}
public extension Int {
    func formatInt()-> String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        numberFormatter.groupingSeparator = ","
        return numberFormatter.string(from: NSNumber(value: self))!
    }
}
public extension FloatingPoint {
    func toRadians() -> Self {
        return self * .pi / 180
    }
}
