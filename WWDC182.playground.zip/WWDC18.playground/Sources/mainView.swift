
//The main view of the playground

import UIKit

public class mainView: UIView {
    let Colors = Constants.Colors
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.addGradientWith(colors: [Colors[0].cgColor, Colors[1].cgColor])
    }
    
    public func addStars() {
        for i in 60 {
            let randomDimen = CGFloat(getRandomDecimal(from: 1.2, to: 2.1))
            var starRect = CGRect(x: 0, y: 0, width: randomDimen, height: randomDimen)
            starRect.origin = getRandomPoint(i: i)
            
            let path = UIBezierPath(ovalIn: starRect)
            let circle = CAShapeLayer()
            circle.path = path.cgPath
            circle.fillColor = Colors[2].cgColor
            circle.opacity = 0
            self.layer.insertSublayer(circle, at: 1)
            
            let animationShow = CABasicAnimation(keyPath: "opacity")
            animationShow.fromValue = 0
            animationShow.toValue = getRandomDecimal(from: 0.6, to: 0.99)
            animationShow.duration = 3
            animationShow.beginTime = CACurrentMediaTime() + CFTimeInterval(getRandomDecimal(from: 2, to: 17))
            animationShow.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationShow.isRemovedOnCompletion = false
            animationShow.fillMode = kCAFillModeForwards
            
            circle.add(animationShow, forKey: "showStar")
        }
    }
    
    func getRandomPoint(i: Int)-> CGPoint {
        var x: CGFloat = 10
        
        var height: CGFloat = self.frame.height/2.8
        if i > 20 && i < 40 {
            x = self.frame.width/3
            height = self.frame.height/9
        }else if i > 40 {
            x = (self.frame.width/3)*2
        }
        let skyRect = CGRect(x: x, y: 0, width: (self.frame.width/2)-10, height: height)
        let origin = skyRect.origin
        let randomPoint = CGPoint(x: CGFloat(arc4random_uniform(UInt32(skyRect.width))) + origin.x, y: CGFloat(arc4random_uniform(UInt32(skyRect.height))) + origin.y)
        return randomPoint
    }
    
    func getRandomDecimal(from: Float, to: Float) -> Float{
        return Float(arc4random()) / Float(UINT32_MAX) * abs(from - to) + min(from, to)
    }
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


