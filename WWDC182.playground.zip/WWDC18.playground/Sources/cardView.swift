
//The card view which displays some info types including: a linear graph, a circular graph, an elevation like view, and the 360 view.

import UIKit

public class cardView: UIView {
    
    public static let Colors = Constants.Colors
    
    public var title: UILabel!
    public var value: UILabel!
    
    private var dataGraphView: graphView!
    private var dataMountainsView: mountainsView!
    private var dataCircularView: circularGraph!
    public var dataView360: view360!
    
    public init(frame: CGRect, card: Card) {
        super.init(frame: frame)
        
        let Colors = Constants.Colors
        
        self.addGradientWith(colors: [Colors[4].cgColor, Colors[7].cgColor])
        self.clipsToBounds = true
        self.layer.cornerRadius = frame.height/10.66
        
        let width = frame.width
        let height = frame.height
        
        let width10th = width/10
        
        title = UILabel(frame: CGRect(x: width10th, y: width10th, width: width-((width10th)*2), height: height/6))
        
        value = UILabel(frame: CGRect(x: title.frame.minX, y: height-((width10th)+(title.frame.height*1.8)), width: width-((width10th)*2), height: title.frame.height*1.8))
        
        title.text = card.title
        title.textColor = Colors[2]
        title.setupLabel(bold: true, fontSize: height/6.4)
        title.textAlignment = .left
        
        value.text = card.value
        value.textColor = Colors[2]
        value.setupLabel(bold: true, fontSize: height/3.2)
        value.textAlignment = .left
        
        let dataViewRect = CGRect(x: 0, y: title.frame.maxY+3, width: width, height: height-title.frame.maxY-value.frame.height-(width10th)+3)
        
        if card.type == .graph {
            dataGraphView = graphView(frame: dataViewRect, population: card.data as! [Double])
            self.addSubview(dataGraphView)
        }else if card.type == .mountains {
            dataMountainsView = mountainsView(frame: dataViewRect)
            self.addSubview(dataMountainsView)
        }else if card.type == .circular {
            dataCircularView = circularGraph(frame: CGRect(x: value.frame.minX, y: dataViewRect.origin.y, width: dataViewRect.width-((width10th)*2), height: dataViewRect.width-((width10th)*2)), city: card.data as! City)
            
            value.frame = CGRect(x: dataCircularView.frame.minX+(height/8), y: dataViewRect.minY+(height/12.3), width: dataCircularView.frame.width-(height/4), height: dataCircularView.frame.height-(height/6.15))
            
            let keyView = UIView(frame: CGRect(x: (width/12), y: dataCircularView.frame.maxY+(height/29), width: width-((width/15)*2), height: height-(dataCircularView.frame.maxY+(height/20))))
            
            let valuesKey = ["Land", "Water"]
            let colorsKey = [Colors[6], Colors[8].withAlphaComponent(0.4)]
            
            for i in valuesKey.count {
                let keyImg = UIImageView(frame: CGRect(x: CGFloat(i)*(keyView.frame.width/2), y: 0, width: keyView.frame.height, height: keyView.frame.height))
                keyImg.backgroundColor = colorsKey[i]
                keyImg.layer.cornerRadius = keyImg.frame.height/2
                
                let keyLabel = UILabel(frame: CGRect(x: keyImg.frame.maxX+(height/40), y: 0, width: (keyView.frame.width/2)-(keyView.frame.height+(height/40)), height: keyView.frame.height))
                
                keyLabel.setupLabel(bold: true, fontSize: height/17)
                keyLabel.textAlignment = .left
                keyLabel.text = valuesKey[i]
                keyLabel.textColor = Colors[2]
                
                keyView.addSubview(keyImg)
                keyView.addSubview(keyLabel)
            }
            
            self.addSubview(keyView)
            self.addSubview(dataCircularView)
        }else if card.type == .threesixty {
            
            title.shadowColor = UIColor.black
            title.textColor = Colors[6]
            title.shadowOffset = CGSize(width: 0.5, height: 0.5)
            title.layer.shadowOpacity = 0.3
            title.layer.shadowRadius = 2
            
            value.shadowColor = UIColor.white
            value.shadowOffset = CGSize(width: 0.5, height: 0.5)
            value.layer.shadowOpacity = 0.3
            value.layer.shadowRadius = 2
            value.textColor = Colors[8]
            
            dataView360 = view360(frame: self.bounds, image: UIImage(named: (card.data as! String).lowercased().replacingOccurrences(of: " ", with: "")+"d")!)
            self.insertSubview(dataView360, at: 1)
            
            dataView360.startAnimatingCam()
        }
        
        self.addSubview(title)
        self.addSubview(value)
    }
    
    public func update(card: Card) {
        title.text = card.title
        value.text = card.value
    }
    
    public func update3d(expand: Bool) {
        let scrollView = self.superview as! UIScrollView
        
        if expand {
            let mainWidth = (scrollView.superview?.frame.width)!
            let mainHeight = (scrollView.superview?.frame.height)!
            
            title.alpha = 0
            value.alpha = 0
            
            self.layer.cornerRadius = 0
            self.frame = CGRect(x: self.frame.maxX-mainWidth+(self.frame.height/10.66), y: 0, width: mainWidth, height: mainHeight)
            
            dataView360.stopAnimatingCam()
            dataView360.frame.size = CGSize(width: mainWidth, height: mainHeight)
            dataView360.sceneView.frame.size = CGSize(width: mainWidth, height: mainHeight)
        }else {
            title.alpha = 1
            value.alpha = 1
            
            let lastcardRect = (scrollView.viewWithTag(4)?.frame)!
            
            self.frame = CGRect(x: lastcardRect.maxX+(lastcardRect.height/10.66), y: 0, width: lastcardRect.width, height: lastcardRect.height)
            self.layer.cornerRadius = lastcardRect.height/10.66
            
            dataView360.startAnimatingCam()
            dataView360.frame.size = lastcardRect.size
        }
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private class graphView: UIView {
        
        var points: [Double]!
        
        init(frame: CGRect, population: [Double]) {
            super.init(frame: frame)
            points = population
            self.backgroundColor = .clear
        }
        
        override func draw(_ rect: CGRect) {
            
            let pointX = { (point: Int) -> CGFloat in
                return CGFloat(point+1) * (rect.width/CGFloat(self.points.count))
            }
            let pointY = { (population: Double) -> CGFloat in
                return (rect.height-(CGFloat(population) / CGFloat(self.points.max()!) * (rect.height-20)))+5
            }
            
            var pointsXY = [CGPoint(x: 0, y: pointY(points[0]))]
            for i in points.count-1 {
                pointsXY.append(CGPoint(x: pointX(i+1), y: pointY(points[i+1])))
            }
            
            Colors[6].setStroke()
            
            let graphPath = pointsXY.getCurvedFromStraight()
            graphPath.lineWidth = rect.height/4.13
            
            let shadowPath = graphPath.copy() as! UIBezierPath
            
            shadowPath.addLine(to: CGPoint(x: rect.width, y: rect.height))
            shadowPath.addLine(to: CGPoint(x: 0, y: rect.height))
            shadowPath.close()
         
            shadowPath.addClip()
            
            let context = UIGraphicsGetCurrentContext()!
            let colors = [Colors[9].withAlphaComponent(0.3).cgColor, UIColor(white: 1, alpha: 0).cgColor]
            let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors as CFArray, locations: [0.0, 1.0])!
            
            context.drawLinearGradient(gradient, start: CGPoint(x: 0, y: pointY(points.max()!)), end: CGPoint(x: 0, y: bounds.height), options: [])
            
            graphPath.stroke()
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    private class mountainsView: UIView {
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            self.backgroundColor = .clear
        }
        
        override func draw(_ rect: CGRect) {
            
            let paths1 = [CGPoint(x: 0, y: 20), CGPoint(x: rect.width, y: rect.height-10)]
            let paths2 = [CGPoint(x: 0, y: rect.height-10), CGPoint(x: rect.width/2, y: 20), CGPoint(x: rect.width, y: rect.height-10)]
            let paths3 = [CGPoint(x: rect.width/2, y: rect.height-10), CGPoint(x: rect.width, y: 20)]
            
            let mountainPath1 = paths1.getCurvedFromStraight()
            let mountainPath2 = paths2.getCurvedFromStraight()
            let mountainPath3 = paths3.getCurvedFromStraight()
            
            mountainPath1.addLine(to: CGPoint(x: 0, y: rect.height-10))
            mountainPath2.addLine(to: CGPoint(x: 0, y: rect.height-10))
            mountainPath3.addLine(to: CGPoint(x: rect.width, y: rect.height-10))
            
            mountainPath1.close()
            mountainPath2.close()
            mountainPath3.close()
            
            Colors[6].withAlphaComponent(0.6).setFill()
            
            mountainPath1.fill()
            
            Colors[6].withAlphaComponent(0.3).setFill()
            
            mountainPath2.fill()
            mountainPath3.fill()
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    private class circularGraph: UIView {
        
        var city: City!
        
        init(frame: CGRect, city: City) {
            super.init(frame: frame)
            self.backgroundColor = .clear
            self.city = city
        }
        
        override func draw(_ rect: CGRect) {
            let totalArea = CGFloat(city.getTotalArea())
            let waterArea = CGFloat(city.waterArea)
            
            let waterAreaDegree = CGFloat((waterArea/totalArea)*360)
            let landAreaDegree = CGFloat(360-waterAreaDegree)
            
            let landStartAngle: CGFloat = 0
            let landEndAngle = landAreaDegree.toRadians()
            
            let center = CGPoint(x: rect.width/2, y: rect.height/2)
            
            let landArc = UIBezierPath(arcCenter: center, radius: (rect.height-(rect.height/9.9))/2, startAngle: landStartAngle, endAngle: landEndAngle, clockwise: true)
            let waterArc = UIBezierPath(arcCenter: center, radius: (rect.height-(rect.height/9.9))/2, startAngle: landEndAngle, endAngle: landStartAngle, clockwise: true)
            
            landArc.lineWidth = rect.height/9.9
            waterArc.lineWidth = rect.height/9.9
            
            Colors[6].setStroke()
            landArc.stroke()
            Colors[8].withAlphaComponent(0.4).setStroke()
            waterArc.stroke()
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
