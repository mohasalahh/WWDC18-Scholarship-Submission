
//The details scroll view which displays some cards with some information.

import UIKit

public class detailsScrollView: UIScrollView, UIGestureRecognizerDelegate {
    
    var cards = [Card]()
    var cardSize = CGSize()
    
    public var viewd = false
    let pan360 = UIPanGestureRecognizer()
    let tap360 = UITapGestureRecognizer()
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        cardSize = CGSize(width: frame.height/1.26, height: frame.height)
        
        self.contentSize = CGSize(width: (cardSize.width*5)+((cardSize.height/10.66)*7), height: frame.height)
        self.showsHorizontalScrollIndicator = false
        self.isPagingEnabled = true
        self.addGestureRecognizer(pan360)
        
        pan360.delegate = self
        tap360.addTarget(self, action: #selector(handleTap(sender:)))
        
        update(city: Constants.Cities[0])
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
    public func update(city: City) {
        let population = city.population
        
        cards = [
            Card.init(title: "Population", value: String(describing: population[population.count-1])+" M", type: .graph, data: population),
            Card.init(title: "Area", value: String(describing: city.getTotalArea().formatInt())+" KM²", type: .circular, data: city),
            Card.init(title: "Elevation", value: String(describing: city.elevation)+" M", type: .mountains, data: city),
            Card.init(title: "Density", value: String(describing: Int(population[population.count-1]*1000000)/city.getTotalArea())+"/KM²", type: .graph, data: population),
            Card.init(title: "360° View", value: "Click to Expand", type: .threesixty, data: city.name)
        ]
        
        reloadData()
    }
    
    public func update3d() {
        let cardd = self.viewWithTag(5) as! cardView
        let viewHeight = (self.superview?.frame.height)!
        let viewWidth = (self.superview?.frame.width)!
        
        UIView.animate(withDuration: 1, delay: 0, options: [.curveEaseInOut], animations: {
            
            if !self.viewd {
                self.viewd = true
                self.frame = CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight)
                
                self.pan360.isEnabled = true
                self.pan360.addTarget(cardd.dataView360, action: #selector(cardd.dataView360.handlePan(panRec:)))
                
                self.panGestureRecognizer.isEnabled = false
                cardd.update3d(expand: self.viewd)
            }else {
                self.viewd = false
                self.frame = CGRect(x: 0, y: viewHeight-(viewHeight/4.375)-(viewHeight/46.6), width: viewWidth, height: viewHeight/4.375)
                
                self.pan360.isEnabled = false
                
                self.panGestureRecognizer.isEnabled = true
                cardd.update3d(expand: self.viewd)
            }
            
        }, completion: {finished in
            if !self.viewd {
                cardd.dataView360.sceneView.frame.size = cardd.dataView360.bounds.size
            }
        })
    }
    
    @objc private func handleTap(sender: UITapGestureRecognizer) {
        update3d()
    }
    
    private func reloadData() {
        self.subviews.forEach({ $0.removeFromSuperview() })
        
        for i in cards.count {
            let card = cardView(frame: CGRect(x: (CGFloat(i)*cardSize.width)+((cardSize.height/10.66)*CGFloat(i+1))+(cardSize.height/10.66), y: 0, width: cardSize.width, height: cardSize.height), card: cards[i])
            card.tag = i+1
            
            if i == 4 {
                card.addGestureRecognizer(tap360)
            }
            self.addSubview(card)
        }
    }
}
